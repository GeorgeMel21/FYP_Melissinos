%*************************************************************************
%* MEng Project
%  Programmer: George Alexandros Melissinos
%  Last modify date: 18/03/2025 
%*************************************************************************
%  Function description: 
%      - Build the Gaussian Puff Model
%*************************************************************************
% Input parameters:
%
%     x - wind direction coordinate
%     y - cross-wind direction coordinate
%     H - vertical height of the source
%     sx - x std
%     sy - y std
%     sz - z std
%     Q - contaminant emission rate
%     U - wind velocity
%
% Output:
%
%     C - contaminant concentration
%
%*************************************************************************

function C = Gaussian_Puff_Function(x, y, sx, sy, sz, H, Q, U ,t)

% Calculate the concentration.
  C  = Q ./ (pi*sqrt(2*pi)*sx.*sy.*sz) .* exp(-(x-U*t).^2./(2*sx.^2)-y.^2./(2*sy.^2)-H.^2./(2*sz.^2));
  reset = find(isnan(C) | isinf(C));
  C(reset) = 0; 
end