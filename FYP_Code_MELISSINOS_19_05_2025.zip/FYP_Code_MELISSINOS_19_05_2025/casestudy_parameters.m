switch casestudy
    case 1
        fprintf('Simple Gaussian Puff, constant wind direction at angle pi/5\n')
        theta=pi/5*ones(timesteps,1);
        %%%% initial source points (coordinates in m)
        x =-500;
        y =-150;
        H=15;%%height of initial source points (m)
        label='S1';
        Q=10;%%gas mass kg
        fprintf('Gas parameters settled\n')
    case 2
        fprintf('3 lined Gaussian Puffs, constant wind direction at angle -pi/6\n')
        theta=-pi/6*ones(timesteps,1);
        %%%% initial source points (coordinates in m)
        x = [-500 -500 -500];
        y = [0 150 300];
        H = [15 15 15];%%height of initial source points (m)
        Q=[10 10 10];%%gas mass kg
        label=[' S1'; ' S2'; ' S3'];
        fprintf('Gas parameters settled\n')
    case 3
        fprintf('3 lined Gaussian Puffs, one wind change from pi/5 to -pi/5\n')
        theta=[pi/5*ones(timesteps-25,1);-pi/5*ones(25,1)];
        %%%% initial source points (coordinates in m)
        x = [-500 -500 -500];
        y = [0 150 300];
        H = [15 15 15];%%height of initial source points (m)
        Q=[10 10 10];%%gas mass kg
        label=[' S1'; ' S2'; ' S3'];
        fprintf('Gas parameters settled\n')
    case 4
        fprintf('4 non-lined Gaussian Puffs, one wind change from pi/5 to -pi/5\n')
        theta=[pi/5*ones(timesteps-25,1);-pi/5*ones(25,1)];
        %%%% initial source points (coordinates in m)
        x = [-500 -600 -500 -600];
        y = [-150 0 150 300];
        H = [15 15 15 15];%%height of initial source points (m)
        Q=[10 10 10 10];%%gas mass kg
        label=[' S1'; ' S2'; ' S3'; ' S4'];
        fprintf('Gas parameters settled\n')
end