function sorted_nodes=find_least_spaced_central_nodes(cross_points)
Nm=size(cross_points,1);
distances = zeros(Nm, 1);
for i=1:Nm
    next_i=mod(i,Nm)+1; % Handles wrap-around (N?1)
    distances(i) = norm(cross_points(i,:)-cross_points(next_i,:)); % Euclidean distance
end
Sumdistnode=zeros(Nm, 1);
Sumdistnode(1)=distances(1)+distances(Nm);
for i=2:Nm
    Sumdistnode(i)=distances(i)+distances(i-1);
end
node_distances = [(1:Nm)', Sumdistnode];
% Sort nodes by total distance (ascending order)
[~, sorted_indices] = sort(node_distances(:, 2),'ascend');
sorted_nodes = node_distances(sorted_indices, :);