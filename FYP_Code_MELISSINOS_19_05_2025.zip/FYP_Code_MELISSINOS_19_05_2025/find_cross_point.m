function cross_point=find_cross_point(pointx,pointy,Blocklimits)
%
X_low=Blocklimits(1);
X_mid=Blocklimits(2);
X_high=Blocklimits(3);
Y_low=Blocklimits(4);
Y_mid=Blocklimits(5);
Y_high=Blocklimits(6);
stepp=X_high-X_low; %%%% to handle numerical errors 
if pointx >= X_low-stepp*0.01 && pointx < X_mid
    if pointy >= Y_low && pointy < Y_mid
        cross_point = [X_low Y_low];
    elseif pointy >= Y_mid-stepp*0.01 && pointy <= Y_high+stepp*0.01
        cross_point = [X_low Y_high];
    end
elseif pointx >= X_mid-stepp*0.01 && pointx <= X_high+stepp*0.01
    if pointy >= Y_low-stepp*0.01 && pointy < Y_mid
        cross_point = [X_high Y_low];
    elseif pointy >= Y_mid-stepp*0.01 && pointy <= Y_high+stepp*0.01
        cross_point = [X_high Y_high];
    end
end
end