Case=3;

load(['Testdata/Case',num2str(Case),'_percin_10.mat'])
load(['Testdata/Case',num2str(Case),'_percin_20.mat'])
load(['Testdata/Case',num2str(Case),'_percin_30.mat'])
load(['Testdata/Case',num2str(Case),'_percin_40.mat'])
load(['Testdata/Case',num2str(Case),'_percin_50.mat'])

load(['Testdata/Case',num2str(Case),'_area_fraction_10.mat'])
load(['Testdata/Case',num2str(Case),'_area_fraction_20.mat'])
load(['Testdata/Case',num2str(Case),'_area_fraction_30.mat'])
load(['Testdata/Case',num2str(Case),'_area_fraction_40.mat'])
load(['Testdata/Case',num2str(Case),'_area_fraction_50.mat'])

%%%% metric 1---erroneous ms in gas
figure()
timeaxis=medtime:timesteps;
plot(timeaxis,percin_10,'-o','Color','b','LineWidth',2)
hold on
plot(timeaxis,percin_20,'-o','Color','r','LineWidth',2)
hold on
plot(timeaxis,percin_30,'-+','Color','k','LineWidth',2)
hold on
plot(timeaxis,percin_40,'-+','Color','m','LineWidth',2)
hold on
plot(timeaxis,percin_50,'-*','Color','g','LineWidth',2)
grid on
xlabel('Time (seconds)','Interpreter', 'latex','FontSize',14)
ylabel('\% of Mobile Sensors in gas','Interpreter', 'latex','FontSize',14)
ylim([0 ceil((max(percin_50)+10)/10)*10])
title('Percentage of M.S. sensors in gas area at the end of each timestep')
set(gca, 'TickLabelInterpreter', 'latex');
legend({'N_m=10','N_m=20','N_m=30','N_m=40','N_m=50'})

%%%% metric 2--- area percentages
figure()
timeaxis=medtime:timesteps;
plot(timeaxis,area_fraction_10,'-o','Color','b','LineWidth',2)
hold on
plot(timeaxis,area_fraction_20,'-o','Color','r','LineWidth',2)
hold on
plot(timeaxis,area_fraction_30,'-+','Color','k','LineWidth',2)
hold on
plot(timeaxis,area_fraction_40,'-+','Color','m','LineWidth',2)
hold on
plot(timeaxis,area_fraction_50,'-*','Color','g','LineWidth',2)
grid on
xlabel('Time (seconds)','Interpreter','latex','FontSize',14)
ylabel('$E_{MSp}/E_{Gas}$','Interpreter','latex','FontSize',14)
%ylim([0 1])
title('Areas fraction at the end of each timestep')
set(gca, 'TickLabelInterpreter', 'latex');
legend({'N_m=10','N_m=20','N_m=30','N_m=40','N_m=50'})

if Case==2
load(['Testdata/Case',num2str(Case),'_percin_10_500.mat'])
load(['Testdata/Case',num2str(Case),'_percin_20_500.mat'])
load(['Testdata/Case',num2str(Case),'_percin_30_500.mat'])
load(['Testdata/Case',num2str(Case),'_percin_10_2000.mat'])
load(['Testdata/Case',num2str(Case),'_percin_20_2000.mat'])
load(['Testdata/Case',num2str(Case),'_percin_30_2000.mat'])

load(['Testdata/Case',num2str(Case),'_area_fraction_10_500.mat'])
load(['Testdata/Case',num2str(Case),'_area_fraction_20_500.mat'])
load(['Testdata/Case',num2str(Case),'_area_fraction_30_500.mat'])
load(['Testdata/Case',num2str(Case),'_area_fraction_10_2000.mat'])
load(['vCase',num2str(Case),'_area_fraction_20_2000.mat'])
load(['Testdata/Case',num2str(Case),'_area_fraction_30_2000.mat'])

%%%% metric 1---erroneous ms in gas
figure()
timeaxis=medtime:timesteps;
plot(timeaxis,percin_10_500,'-o','Color','b','LineWidth',2)
hold on
plot(timeaxis,percin_10,'-o','Color','r','LineWidth',2)
hold on
plot(timeaxis,percin_10_2000,'-o','Color','m','LineWidth',2)
hold on
plot(timeaxis,percin_20_500,'-+','Color','b','LineWidth',2)
hold on
plot(timeaxis,percin_20,'-+','Color','r','LineWidth',2)
hold on
plot(timeaxis,percin_20_2000,'-+','Color','m','LineWidth',2)
hold on
plot(timeaxis,percin_30_500,'-d','Color','b','LineWidth',2)
hold on
plot(timeaxis,percin_30,'-d','Color','r','LineWidth',2)
hold on
plot(timeaxis,percin_30_2000,'-d','Color','m','LineWidth',2)
grid on
xlim([50 120])
xlabel('Time (seconds)','Interpreter', 'latex','FontSize',14)
ylabel('\% of Mobile Sensors in gas','Interpreter', 'latex','FontSize',14)
ylim([0 ceil((max(percin_50)+10)/10)*10])
title('Percentage of M.S. sensors in gas area at the end of each timestep')
set(gca, 'TickLabelInterpreter', 'latex');
legend({'N_m=10, N_s=500','N_m=10, N_s=1000','N_m=10, N_s=2000',...
    'N_m=20, N_s=500','N_m=20, N_s=1000','N_m=20, N_s=2000',...
   'N_m=30, N_s=500','N_m=30, N_s=1000','N_m=30, N_s=2000'})

figure()
timeaxis=medtime:timesteps;
plot(timeaxis,area_fraction_10_500,'-o','Color','b','LineWidth',2)
hold on
plot(timeaxis,area_fraction_10,'-o','Color','r','LineWidth',2)
hold on
plot(timeaxis,area_fraction_10_2000,'-o','Color','m','LineWidth',2)
hold on
plot(timeaxis,area_fraction_20_500,'-+','Color','b','LineWidth',2)
hold on
plot(timeaxis,area_fraction_20,'-+','Color','r','LineWidth',2)
hold on
plot(timeaxis,area_fraction_20_2000,'-+','Color','m','LineWidth',2)
hold on
plot(timeaxis,area_fraction_30_500,'-d','Color','b','LineWidth',2)
hold on
plot(timeaxis,area_fraction_30,'-d','Color','r','LineWidth',2)
hold on
plot(timeaxis,area_fraction_30_2000,'-d','Color','m','LineWidth',2)
grid on
xlabel('Time (seconds)','Interpreter','latex','FontSize',14)
ylabel('$E_{MSp}/E_{Gas}$','Interpreter','latex','FontSize',14)
xlim([50 120])
%ylim([0 1])
title('Areas fraction at the end of each timestep')
set(gca, 'TickLabelInterpreter', 'latex');
legend({'N_m=10, N_s=500','N_m=10, N_s=1000','N_m=10, N_s=2000',...
    'N_m=20, N_s=500','N_m=20, N_s=1000','N_m=20, N_s=2000',...
   'N_m=30, N_s=500','N_m=30, N_s=1000','N_m=30, N_s=2000'})

end