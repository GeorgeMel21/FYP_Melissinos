function new_pos=move_single_direct(xi,yi,movedir,stepstomove)
%%%% movement on a single direction for a defined number of steps
switch movedir
    case 'right'
        %%% move right
        new_pos(1)=xi+stepstomove;
        new_pos(2)=yi;
    case 'up'
        %%% move right
        new_pos(1)=xi;
        new_pos(2)=yi+stepstomove;
    case 'left'
        %%% move left
        new_pos(1)=xi-stepstomove;
        new_pos(2)=yi;
    case 'down'
        new_pos(1)=xi;
        new_pos(2)=yi-stepstomove;
end
end