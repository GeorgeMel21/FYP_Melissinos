function overlapping=check_overlapping(new_single_pos,ms_pos,ms,timeind)
Nm=size(ms_pos,1);
new_single_pos=squeeze(new_single_pos)';
overlapping=ismember(new_single_pos,squeeze(ms_pos(1:max(1,ms-1),:,timeind+1)),'rows')...
    +ismember(new_single_pos,squeeze(ms_pos(min(ms+1,Nm):Nm,:,timeind)),'rows');
end