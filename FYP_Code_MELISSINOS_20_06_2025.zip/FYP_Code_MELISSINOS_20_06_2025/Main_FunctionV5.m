%*************************************************************************
%  MEng Project
%  Programmer: George Alexandros Melissinos
%  Last modify date: 17/05/2025
%*************************************************************************
%  Code description:
%   - The entire design
%
%
%*************************************************************************
clc
close all
clear all
%% Initialize sensor parameters
ns = 1000; %%% Number of Static Sensors
Nm=35; %%% Number of Mobile Sensors 
%% Part I: set gas model parameters
casestudy=5; %%% select a case study
%%%% time configuaration (s)
timesteps=101; %total time steps
t=linspace(0,100,timesteps); %s
%%% minimum time step
Dt=max(diff(t));
medtime=50; %time step in which the static sensors take measurement
U = 10*ones(timesteps,1); %wind speed norm for each timestep (m/s)
% Parameters of 4-source Gaussian Puff Model
casestudy_parameters;
%%%% number of sources of Puff models
nosources=length(x);
%%% xy space dimensions (m)
xmin=-1000; xmax=1000;
ymin=-1000; ymax=1000;
Xdim=xmax-xmin;
Ydim=ymax-ymin;
resolution_step=5;
xstep = 25; %%%% has to be much larger than the resolution (x5)
%% Part II: Create the Gas Model
xlimits = [xmin xmax];
ylimits = [ymin ymax];
%list of x coordinates
x0 = xmin + (0:resolution_step:Xdim);
%list of y coordinates
y0 = ymin + (0:resolution_step:Ydim);
[xmesh, ymesh] = meshgrid(x0, y0);

%%%%
noofdirection_changes=unique(theta);
Dtheta=diff(theta);
changedirtime=[1 find(Dtheta~=0)];
xsource_current=x;
ysource_current=y;

for changes=1:length(changedirtime)
    directionstart=changedirtime(changes)+1;
    if changes<length(changedirtime)
        directionend=changedirtime(changes+1);
    else
        directionend=length(t);
    end
    xsource_currentappend=xsource_current(directionstart-1,:)+...
        repmat(U(directionstart:directionend).*cos(theta(directionstart:directionend)).*...
        (t(directionstart:directionend)-t(directionstart))',[1 nosources]);
    xsource_current=[xsource_current;xsource_currentappend];
    ysource_currentappend=ysource_current(directionstart-1,:)+...
        repmat(U(directionstart:directionend).*sin(theta(directionstart:directionend)).*...
        (t(directionstart:directionend)-t(directionstart))',[1 nosources]);
    ysource_current=[ysource_current;ysource_currentappend];
end

figure()
plot(xsource_current,ysource_current,'o--','LineWidth',2)
configure_graph(xmin, xmax, ymin, ymax, xstep)
configure_colorbar('$C$ ($mg/m^3$)');
title('Movement of Gaussian Puff masses centers from t=0 to t=t_{end}')
if nosources==4
    L25=legend({'Center of Mass 1','Center of Mass 2','Center of Mass 3','Center of Mass 4'});
elseif nosources==1
    L25=legend({'Center of Mass 1'}); 
end
% Summation of all sources
% zero initialization of consentration at all timesteps (XxYxTimesteps)
c=zeros(size(xmesh,1),size(xmesh,2),timesteps);
sx=zeros(size(xmesh,1),size(xmesh,2));
sy=sx;
sz=sx;
xs=x; ys=y; chwind=0; tref=0;
for i=1:nosources
    %%% absolute wind-direction distances from the initial source
    xabs=abs(xmesh-xs(i))*cos(theta(1))+(ymesh-ys(i))*sin(theta(1));
    %%% compute initial stds (before the 1st wind change)
    [sx(:,:,i), sy(:,:,i), sz(:,:,i)]=Standard_Deviations(xabs);
end
for tstep=1:timesteps
    %%%%%% check if wind changed direction at this timestep
    if tstep==changedirtime(min(chwind+2,changes))+1
        xs=xsource_current(tstep,:);
        ys=ysource_current(tstep,:);
        chwind=chwind+1;
        tref=tstep-1;
        for i=1:nosources
            %%% add absolute distances from the new source towards the new
            %%% wind direction
            %%% update stds (adding the new distances from the new source)
            [sx(:,:,i), sy(:,:,i), sz(:,:,i)]=...
                Standard_Deviations(xabs);
        end
    end
    for i = 1 : nosources
        %%% coordinate transformation according to the wind direction
        xprime=(xmesh-xs(i))*cos(theta(tstep))+(ymesh-ys(i))*sin(theta(tstep));
        yprime=-(xmesh-xs(i))*sin(theta(tstep))+(ymesh-ys(i))*cos(theta(tstep));
        c(:,:,tstep) = c(:,:,tstep) + Gaussian_Puff_Function(xprime, yprime,...
            squeeze(sx(:,:,i)),squeeze(sy(:,:,i)),squeeze(sz(:,:,i)), H(i),...
            Q(i), U(tstep) ,t(tstep-tref));
    end
end
clist = [0.001, 0.01, 0.02, 0.05, 0.1 ];
c = c*1e6;  % mg/m^3

% Plot the model
f1 = figure();
for tstep=1:timesteps
    hold off
    Multi_sources_model_plot;
    configure_graph(xmin, xmax, ymin, ymax, xstep)
    configure_colorbar('$C$ ($mg/m^3$)');
    movegui(f1,'northwest');
    set(gcf,'Color',[1,1,1]);
    pause(0.1)
    if tstep==27||tstep==46||tstep==69||tstep==89||tstep==100
        o=[];
    end
end
hold on
plot(xsource_current,ysource_current,'LineWidth',2)
clear f1


%% Part III: Static Sensor Generation
% The generation of static sensors
tstep=medtime; %%static sensor are activated at a time in which the total
%%% gas has already a nearly fully-connected structure
f3 = figure();
Multi_sources_model_plot;
title('Static Sensor Placement and Pairs')
configure_graph(xmin, xmax, ymin, ymax, xstep)
configure_colorbar('$C$ ($mg/m^3$)');
movegui(f3,'north');
set(gcf,'Color',[1,1,1]);

%%% ns is the number of static sensors
distancemax_static_pair=150;
SS_X = rand(1,ns)*(xmax-xmin)+xmin;
SS_Y = rand(1,ns)*(ymax-ymin)+ymin;
index = 1:ns;
%%% static sensors' coordinates
SS_record = [index' SS_X' SS_Y'];
plot(SS_record(i,2),SS_record(i,3),'r.','MarkerSize',10);
for i = 2:ns
    plot(SS_record(i,2),SS_record(i,3),'r.','MarkerSize',10);
end
%%% distances between static sensors
distances=sqrt((SS_record(:,2)-SS_record(:,2)').^2+(SS_record(:,3)-SS_record(:,3)').^2);
for i = 1:ns
    for j = 1:ns
        %distance = sqrt((SS_record(i,2)-SS_record(j,2))^2+(SS_record(i,3)-SS_record(j,3))^2);
        if distances(i,j) <= distancemax_static_pair
            line([SS_record(i,2) SS_record(j,2)], [SS_record(i,3) SS_record(j,3)], 'LineStyle', ':','HandleVisibility', 'off');
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear f3


% %% Part III: TRYING Grid-Like Static Sensor Generation (Concentric Square Grid-Based) 
% tstep = medtime;
% f3 = figure();
% Multi_sources_model_plot;
% title('Static Sensor Placement and Pairs');
% configure_graph(xmin, xmax, ymin, ymax, xstep);
% configure_colorbar('$C$ ($mg/m^3$)');
% movegui(f3, 'north');
% set(gcf, 'Color', [1, 1, 1]);
% 
% % Parameters
% spacing = 150;
% center_x = (xmin + xmax) / 2;
% center_y = (ymin + ymax) / 2;
% max_radius = min((xmax - xmin), (ymax - ymin)) / 2;
% 
% SS_coords = [];
% 
% % Loop over concentric square layers
% for offset = 0:spacing:(max_radius - spacing/2)
%     x_min = center_x - offset;
%     x_max = center_x + offset;
%     y_min = center_y - offset;
%     y_max = center_y + offset;
% 
%     % Horizontal edges (top and bottom)
%     x_vals = x_min:spacing:x_max;
%     y_bottom = y_min * ones(size(x_vals));
%     y_top = y_max * ones(size(x_vals));
%     SS_coords = [SS_coords; x_vals', y_bottom'];
%     SS_coords = [SS_coords; x_vals', y_top'];
% 
%     % Vertical edges (left and right), excluding corners
%     y_vals = (y_min + spacing):spacing:(y_max - spacing);
%     x_left = x_min * ones(size(y_vals));
%     x_right = x_max * ones(size(y_vals));
%     SS_coords = [SS_coords; x_left', y_vals'];
%     SS_coords = [SS_coords; x_right', y_vals'];
% end
% 
% % Remove duplicates
% SS_coords = unique(SS_coords, 'rows', 'stable');
% SS_X = SS_coords(:,1)';
% SS_Y = SS_coords(:,2)';
% ns = numel(SS_X);
% 
% % Record
% index = 1:ns;
% SS_record = [index', SS_X', SS_Y'];
% 
% % Plot sensors
% plot(SS_X, SS_Y, 'r.', 'MarkerSize', 10); hold on;
% 
% % Draw sensor links (dashed if within threshold)
% distancemax_static_pair = 150;
% distances = squareform(pdist(SS_record(:,2:3)));
% for i = 1:ns
%     for j = i+1:ns
%         if distances(i,j) <= distancemax_static_pair
%             line([SS_record(i,2), SS_record(j,2)], ...
%                  [SS_record(i,3), SS_record(j,3)], ...
%                  'LineStyle', ':', 'Color', 'b', 'HandleVisibility', 'off');
%         end
%     end
% end
% 
% clear f3

%% Part IV: Find POIs

% Record the midpoints of selected one-hop links
midpoint_number=0;
midpoint_record=[];

f4 = figure();
Multi_sources_model_plot;
title(['Midpoints of static sensor pairs, t=',num2str(t(tstep)),'sec'])
movegui(f4,'south');
set(gcf,'Color',[1,1,1]);
configure_graph(xmin, xmax, ymin, ymax, xstep)
configure_colorbar('$C$ ($mg/m^3$)');
%%%%%
cmedtime=squeeze(c(:,:,medtime));
%%%% set the concentration threshold (mg/m^&3)
threshold=0.01;
xinds=round((SS_record(:,2)-xmin)/resolution_step+1);
yinds=round((SS_record(:,3)-ymin)/resolution_step+1);
linepointappeared=0;
for i = 1:ns
    for j = 1:ns
        if distances(i,j) <= distancemax_static_pair
            if cmedtime(yinds(i),xinds(i))>threshold
                if cmedtime(yinds(j),xinds(j))<threshold
                    if linepointappeared==1
                        line([SS_record(i,2) SS_record(j,2)], [SS_record(i,3) SS_record(j,3)],...
                            'LineStyle', ':','color','g','HandleVisibility', 'off');
                    else
                        line([SS_record(i,2) SS_record(j,2)], [SS_record(i,3) SS_record(j,3)],...
                            'LineStyle', ':','color','g','DisplayName', sprintf('Static Sensor Pair'));
                        linepointappeared=1;
                    end
                    midpoint_number = midpoint_number + 1;
                    midpoint_X = (SS_record(i,2)+SS_record(j,2))/2;
                    midpoint_Y = (SS_record(i,3)+SS_record(j,3))/2;
                    midpoint_record = [midpoint_record;[midpoint_number midpoint_X midpoint_Y]];
                    if midpoint_number == 1 
                        p4 = plot(midpoint_X, midpoint_Y, 'k+', 'MarkerSize', 6, ...
                                 'DisplayName', sprintf('Midpoints'));
                    else
                        p4 = plot(midpoint_X, midpoint_Y, 'k+', 'MarkerSize', 6, ...
                                 'HandleVisibility', 'off');
                    end
                end
            end
        end
    end
end
hold on
plot(SS_record(1,2), SS_record(1,3), 'bo', 'MarkerSize', 2, ...
        'DisplayName', sprintf('Static Sensors'));
for i = 2:ns
    plot(SS_record(i,2), SS_record(i,3), 'bo', 'MarkerSize', 2, ...
        'HandleVisibility', 'off');
end
xlim([-350 350])
ylim([-250 750])
grid on
legend('Location', 'best');
clear f4

%%%% midpoint record: initial raw data midpoints, noofmidpointsX3
%%%% 1 st collumn: index. 2nd collumn: xcoordinate. 3rd collumn: y
%%%% coordinate

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Number the blocks, put midpoints into blocks

Len = Xdim;
width = Ydim;
grid_number = Len*width/xstep^2;
grid_index = 1:grid_number;
%%% find the grid index of each midpoint
grid_record = [grid_index' zeros(grid_number,20)];
grid_belong=ceil((midpoint_record(:,2)-xmin)/xstep) + ...
    floor((midpoint_record(:,3)-ymin)/xstep)*Len/xstep;
for i = 1:midpoint_number
    grid_record(grid_belong(i),max(find(grid_record(grid_belong(i),:)))+1) = i;
end
%%%% grid_record: which midpoints are included within each indexed grid (row)

% Get the average POI from the midpoints within each grid block
grid_average=grid_average_POIs(grid_index,grid_number,grid_record,midpoint_record);


f5 = figure();
Multi_sources_model_plot;
movegui(f5,'northeast');
set(gcf,'Color',[1,1,1]);
title('Average POIs per grid block and cross points')
configure_graph(xmin, xmax, ymin, ymax, xstep)
configure_colorbar('$C$ ($mg/m^3$)');
gridavfound=0;
for i = 1:grid_number
    if grid_average(i,2) > 0 || grid_average(i,3) > 0
        if gridavfound==0
            plot(grid_average(i,2),grid_average(i,3),'g.','MarkerSize',20,'DisplayName', sprintf('POI block average'));
            gridavfound=1;
        else
        plot(grid_average(i,2),grid_average(i,3),'g.','MarkerSize',20,'HandleVisibility', 'off');
        end
    end
end

% Move the average points to the cross points,
% which are final static sensor POIs
cross_points = [];
%%%% find each block's boundary and mean coordinates
Y_low = floor((1:grid_number)/(Len/xstep))*xstep+ymin;
Y_mid = Y_low + xstep/2;
Y_high = Y_mid + xstep/2;
X_high = ((1:grid_number)-floor((1:grid_number)/(Len/xstep))*(Len/xstep))*xstep+xmin;
X_mid = X_high - xstep/2;
X_low = X_mid - xstep/2;
%%%% reveal the closest cross point for each corresponding average point
for block=1:grid_number
    if grid_average(block,2) > 0 || grid_average(block,3) > 0
        Blocklimits=[X_low(block) X_mid(block) X_high(block)...
            Y_low(block) Y_mid(block) Y_high(block)];
        cross_point=find_cross_point(grid_average(block,2),grid_average(block,3),Blocklimits);
        cross_points = [cross_points;[block cross_point(1) cross_point(2)]];
    end
end

cross_points_number = size(cross_points);
plot(cross_points(1,2),cross_points(1,3),'b.','MarkerSize',20,'DisplayName', sprintf('Cross Points'));
for i = 2:cross_points_number(1,1)
    plot(cross_points(i,2),cross_points(i,3),'b.','MarkerSize',20,'HandleVisibility', 'off');
end
xlim([min(cross_points(:,2))-100 max(cross_points(:,2))+100])
ylim([min(cross_points(:,3))-100 max(cross_points(:,3))+100])
legend('Location', 'best')
clear f5
save('Testbench5_data')
%Nm=50;
%% Part V: Initialize Mobile Sensors
%MS_shape='external';
MS_shape='cycle';
%Nm is the number of mobile sensors

switch MS_shape
    case 'cycle'
        %%%%% find largest distance between POIs and their midpoint
        [unique_cross_coords,ia,ib]=unique(cross_points(:,2:3),'rows');
        unique_cross_points=cross_points(ia,:);
        [Dominant_POIs,maxPOI_dist]=find_dominant_POIdists(unique_cross_points);
        %%% find the initial (not on cross points) coordinates of all mobile
        %%% sensors
        %%% margin
        rmargin=5*xstep;
        %%% anti-diametric m.s. points
        X1=Dominant_POIs(1,1); Y1=Dominant_POIs(1,2);
        X2=Dominant_POIs(2,1); Y2=Dominant_POIs(2,2);
        %%% angle between two consecutive m.s. (radians)
        deltatheta=2*pi/(Nm);
        %%% Radius of the cycle initial m.s. positions form
        Rms=(maxPOI_dist+rmargin)/2;
        %%% Center of the cycle initial m.s. positions form
        Xcms=(X1+X2)/2; Ycms=(Y1+Y2)/2;
        %%% initial angle of the 1st m.s.
        theta1=atan2(Y1-Ycms,X1-Xcms);
        %%% initial angle of the antidiametric m.s.
        thetamiddle=atan2(Y2-Ycms,X2-Xcms); %thetamiddle-theta1=pi rad)
        %initial (not on cross points) coordinates of all mobile
        Xms_initial=Xcms+Rms*cos(theta1+deltatheta*(0:(Nm-1)));
        Yms_initial=Ycms+Rms*sin(theta1+deltatheta*(0:(Nm-1)));
        
        %%% find the block each one m.s. belongs at t=tmed
        blockms=ceil((Xms_initial-xmin)/xstep) + ...
            floor((Yms_initial-ymin)/xstep)*Len/xstep;
        %%% check if we are within the research area limits
        if any(blockms<0)
            error('Mobile sensor positions out of grid limits, reduce the gas area by moving the source positions or reducing the speed')
        end
        %%% find the exact ms initial positions on the suitable crosspoints
        MS_exact_initial=zeros(Nm,2);
        for ms=1:Nm
            Blocklimits=[X_low(blockms(ms)) X_mid(blockms(ms)) X_high(blockms(ms))...
                Y_low(blockms(ms)) Y_mid(blockms(ms)) Y_high(blockms(ms))];
            MS_exact_initial(ms,:)=find_cross_point(Xms_initial(ms),Yms_initial(ms),Blocklimits);
        end
    case 'external'
        Bouncross=boundary(cross_points(:,2),cross_points(:,3));
        Pre_initial_ms_pos=cross_points(Bouncross,2:3);
        MS_exact_initial=Pre_initial_ms_pos;
        Nm=min(Nm,2*size(Bouncross,1));
        Nms_to_add=Nm-size(Bouncross,1);
        if Nms_to_add>0
            %%%% sort the neighboring nodes distances
            sorted_pairs=sort_neighboring_pairs(Pre_initial_ms_pos);
            pairs_to_be_splitted=sorted_pairs(1:Nms_to_add,1:2);
            for p=1:Nms_to_add
                %%% find exact midpoint
                new_midpointx=(Pre_initial_ms_pos(pairs_to_be_splitted(p,1),1)+...
                    Pre_initial_ms_pos(pairs_to_be_splitted(p,2),1))/2;
                new_midpointy=(Pre_initial_ms_pos(pairs_to_be_splitted(p,1),2)+...
                    Pre_initial_ms_pos(pairs_to_be_splitted(p,2),2))/2;
                %%% find the block of midpoint
                blockms=ceil((new_midpointx-xmin)/xstep) + ...
                    floor((new_midpointy-ymin)/xstep)*Len/xstep;
                %%% match it on the closest grid cross point
                Blocklimits=[X_low(blockms) X_mid(blockms) X_high(blockms)...
                    Y_low(blockms) Y_mid(blockms) Y_high(blockms)];
                Accurate_added_node(p,:)=find_cross_point(new_midpointx,new_midpointy,Blocklimits);
                %%% embedd the new nodes
                MS_exact_initial=[MS_exact_initial(1:p+pairs_to_be_splitted(p,1)-1,:); ...
                    Accurate_added_node(p,:); MS_exact_initial(pairs_to_be_splitted(p,2)+p-1:end,:)];
            end
        elseif Nms_to_add<0
            sorted_nodes=find_least_spaced_central_nodes(Pre_initial_ms_pos);
            nodes_to_be_removed=sorted_nodes(1:abs(Nms_to_add),1);
            MS_exact_initial(nodes_to_be_removed,:)=[];
        end
end


%%%plot mobile sensor initial positions
fms = figure();
Multi_sources_model_plot;
movegui(fms,'northeast');
set(gcf,'Color',[1,1,1]);
title('Mobile sensor start positions')
if strcmp(MS_shape,'cycle')
    hold on
    plot([Xms_initial Xms_initial(1)],[Yms_initial Yms_initial(1)],'r.','MarkerSize',16)
end
hold on
plot([MS_exact_initial(:,1);MS_exact_initial(1,1)],...
    [MS_exact_initial(:,2);MS_exact_initial(1,2)],'b.-','MarkerSize',16)
configure_graph(xmin, xmax, ymin, ymax, xstep)
xlim([min(MS_exact_initial(:,1))-100 max(MS_exact_initial(:,1))+100])
ylim([min(MS_exact_initial(:,2))-100 max(MS_exact_initial(:,2))+100])
title('Initial Positions of the Mobile Sensors')
legend({'Ideal Mobile Sensor Positions','Final Initial Positions'})
configure_colorbar('$C$ ($mg/m^3$)');
clear fms

%% Part VI: Movement of Mobile Sensors

fms7 = figure();
clist2=[threshold threshold];
tstep=medtime;
tinterval=5;
%%% time interval for which each sensor redefines its moving strategy
%%% according to the wind's direction in case in gas area
ms_state=zeros(Nm,1); %%% moving state of each ms, from 0-tinterval
%%% initally zero. If in gas, increasing by 1 per tstep.
%%% When reaching tinterval, if still in gas, go to 1. If not still in gas,
%%% state turns to 0. Also turns to 1 or 0 if wind changes direction
%%% similarily.
ms_plan=zeros(Nm,tinterval,2);

%%%%% mobile sensors' current positions
ms_pos=zeros(Nm,2,timesteps-medtime+1);
ms_pos(:,:,1)=MS_exact_initial;
%%%%% mobile sensors' measurements (c and u)
meas_ms=zeros(Nm,3,timesteps-medtime+1);
%%%%% average speed of the mobile sensors while moving
%ms_speed=2*U(medtime);
%%% wind direction
direction=mod(theta(medtime),2*pi);
%%% duration of current wind direction
wind_duration=0;
%%% ms_gasmoved: boolean that states which ms have been moved or
%%% tend to move due to gas during a specific wind direction duration.
ms_gasmoved=zeros(Nm,1);
mstomove=zeros(Nm,1);
msbackwind=zeros(Nm,1);
ms_freespacemoved=zeros(Nm,1);
%%% waiting: boolean that states how many turns should a ms wait to move again
%%% if is behind gas direction (case reached the gas from its back side)
waiting=zeros(Nm,1);
%%% number of timesteps of current wind direction to begin considering free space
if strcmp(MS_shape,'cycle')
    min_duration_wait=10;
else
    min_duration_wait=3;
end
%%%% begin tracking of gas  movement in time from mobile sensors
windchanges=0;
while tstep<timesteps
    %%%% each mobile sensor detects the total concentration level
    %%%% and the wind speed and direction resultant.
    if abs(direction-mod(theta(tstep),2*pi))>0.01
        windchanges=windchanges+1;
        %%% case wind direction changes, update it and reset its duration
        direction=mod(theta(tstep),2*pi);
        wind_duration=0;
        %%% also reset "moved" ms
        ms_gasmoved=zeros(Nm,1);
        ms_State=zeros(Nm,1);
        mstomove=zeros(Nm,1);
        msbackwind=zeros(Nm,1);
    else
        %%% update wind duration of current direction
        wind_duration=wind_duration+1;
        if (wind_duration>=min_duration_wait||windchanges>0)&&sum(ms_gasmoved)>0
            mstomove=zeros(Nm,1);
            if strcmp(MS_shape,'cycle')
                Tailvector=[ms_pos(:,1,tstep-medtime+1) ms_pos(:,2,tstep-medtime+1)]*[cos(direction) sin(direction)]';
                Tailvector_padded=Tailvector.*ms_gasmoved;
                Tailvector_padded=abs(Tailvector_padded);
                Tailvector_padded(Tailvector_padded==0)=Tailvector_padded(Tailvector_padded==0)+20000;
                [minval,tailms]=min(Tailvector_padded);
                ydivide=-1/tan(direction)*(ms_pos(:,1,tstep-medtime+1)-ms_pos(tailms,1,tstep-medtime+1))+...
                    ms_pos(tailms,2,tstep-medtime+1);
                %%%%%%%%%%%%%%%%%%%%%%%
                %%%%%%%!!!!!!!!!!!!!!!
                if sin(direction)>=0
                    mstomove(find(ms_pos(:,2,tstep-medtime+1)>=ydivide))=1;
                else
                    mstomove(find(ms_pos(:,2,tstep-medtime+1)<ydivide))=1;
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                msbackwind=1-mstomove;
                plot(ms_pos(tailms,1,tstep-medtime+1),ms_pos(tailms,2,tstep-medtime+1),'ko','MarkerSize',14)
            else
                wind_vector = [cos(theta(tstep)); sin(theta(tstep))];
                lambda=0.03;%0.03;
                for ms=1:Nm
                    nearest_neighbors=3;
                    xm=ms_pos(ms,1,tstep-medtime+1);
                    ym=ms_pos(ms,1,tstep-medtime+1);    
                    [dCdx, dCdy] = compute_gradient_wls_regularized(xm, ym, squeeze(ms_pos(:,:,tstep-medtime+1)),...
                        squeeze(100*meas_ms(:,1,tstep-medtime)), nearest_neighbors,lambda,wind_vector);
                    grad(ms,:)=[dCdx dCdy];
                    grad(ms,:)=grad(ms,:)./(norm(grad(ms,:))+1e-06);
                    if grad(ms,:)*wind_vector < 0  % dot product<0: opposite to wind
                        msbackwind(ms) = 1;
                    end
                end
                Indication=grad*wind_vector;
                % figure
                 qq=quiver(ms_pos(:,1,tstep-medtime+1),...
                     ms_pos(:,2,tstep-medtime+1),grad(:,1),grad(:,2));
                 hold on
                 wv=repmat(wind_vector',[30 1]);
                 qw=quiver(ms_pos(:,1,tstep-medtime+1),...
                     ms_pos(:,2,tstep-medtime+1),wv(:,1),wv(:,2));
                 hold on
                mstomove=1-msbackwind;
            end
        end
    end
    %%%% for each mobile sensor (ms)
    for ms=1:Nm
        overlapping=0;
        %%% hold its position (xms,yms)
        xms=ms_pos(ms,1,tstep-medtime+1);
        yms=ms_pos(ms,2,tstep-medtime+1);
        %%% find this position in mesh index
        indmsx=find(xmesh(1,:)==xms);
        indmsy=find(ymesh(:,1)==yms);
        %%% get the gas concentration measurement on this m.s.
        meas_ms(ms,1,tstep-medtime+1)=c(indmsy,indmsx,tstep);
        %%% get the wind speed measurement assuming it is uniform
        meas_ms(ms,2,tstep-medtime+1)=U(tstep);
        %%% get the wind direction measurement assuming it is uniform
        meas_ms(ms,3,tstep-medtime+1)=theta(tstep);
        %%% check if concentration exceeds threshold
        %gasmnovecond=meas_ms(ms,1,tstep-medtime+1)>threshold&&waiting(ms)==0;
        if meas_ms(ms,1,tstep-medtime+1)>threshold/2&&waiting(ms)==0&&msbackwind(ms)==0 %%% case IN gas
            ms_gasmoved(ms)=1; %%% if so, list the ms in the moved ones
            %stepstomove=floor(ms_speed*Dt/step)+step;
            %%% synchronize ms state with timestep
            ms_state(ms)=ms_state(ms)+1;
            if ms_state(ms)==6
                %%% if previous plan ended and still in gas,
                %%% renew the plan
                ms_state(ms)=1;
            end
            if ms_state(ms)==1
                %%% if ms needs to move and it is at state 1 or ends a previous plan,
                %%% begin a new time plan
                ms_plan(ms,:,:)=squeeze(timeint_moveplan(ms_pos(ms,1,tstep-medtime+1),...
                    ms_pos(ms,2,tstep-medtime+1),direction,tinterval,xstep));
            end
            %%% update ms position according to the plan
            %%% (check overlapping, if this occurs, wait one timestep)
            overlapping=check_overlapping(ms_plan(ms,ms_state(ms),:),ms_pos,ms,tstep-medtime+1);
            if overlapping==0
                ms_pos(ms,:,tstep-medtime+2)=ms_plan(ms,ms_state(ms),:);
            else
                %%%% case of overlapping, freeze previously updated
                %%%% state, stay at the same position for a timestep
                waiting(ms)=1;
                ms_pos(ms,:,tstep-medtime+2)=ms_pos(ms,:,tstep-medtime+1);
                ms_state(ms)=ms_state(ms)-1;
            end
        else  %%%case NOT IN GAS
            %%% if not in gas but moved from gas
            if ms_state(ms)>0 && ms_state(ms)<5 && ms_gasmoved(ms)==1
                %%%move only until closing of open plan
                %%% update ms position according to the plan (check overlapping
                %%% first)
                overlapping=check_overlapping(ms_plan(ms,ms_state(ms),:),ms_pos,ms,tstep-medtime+1);
                if overlapping==0
                    ms_state(ms)=ms_state(ms)+1;
                    ms_pos(ms,:,tstep-medtime+2)=ms_plan(ms,ms_state(ms),:);
                else
                    waiting(ms)=1;
                    ms_pos(ms,:,tstep-medtime+2)=ms_pos(ms,:,tstep-medtime+1);
                end
                if ms_state(ms)>=5
                    %%% if plan finishes for a gas-moved ms, do not open new plan
                    %%% since the ms in currently not in gas and does not
                    %%% need movement yet
                    ms_state(ms)=0;
                end
                %%% if not in gas, back from gas, and wind duration >min_duration_wait
            elseif wind_duration>=min_duration_wait && ms_state(ms)<=5 && mstomove(ms)==0&& waiting(ms)==0
                ms_state(ms)=ms_state(ms)+1;
                if ms_state(ms)==6
                    %%% if previous plan ended and still NOT IN gas,
                    %%% renew the plan
                    ms_state(ms)=1;
                end
                if ms_state(ms)==1
                    %%% if ms needs to move TO FREE SPACE
                    %%% and it is at state 1 or ends a previous plan,
                    %%% begin a new time plan
                    ms_plan(ms,:,:)=squeeze(timeint_moveplan(ms_pos(ms,1,tstep-medtime+1),...
                        ms_pos(ms,2,tstep-medtime+1),direction,tinterval,xstep));
                end
                %%% update ms position according to the plan (check
                %%% ovelapping first)
                overlapping=check_overlapping(ms_plan(ms,ms_state(ms),:),ms_pos,ms,tstep-medtime+1);
                if overlapping==0
                    ms_pos(ms,:,tstep-medtime+2)=ms_plan(ms,ms_state(ms),:);
                else
                    %%%% case of overlapping, freeze previously updated
                    %%%% state, stay at the same position for a timestep
                    waiting(ms)=1;
                    ms_pos(ms,:,tstep-medtime+2)=ms_pos(ms,:,tstep-medtime+1);
                    ms_state(ms)=ms_state(ms)-1;
                end
            else
                %%% same position if wind duration <min_duration_wait and not in gas
                %%% or reached gas from behind and have to wait
                %%%% same position
                ms_pos(ms,:,tstep-medtime+2)=ms_pos(ms,:,tstep-medtime+1);
            end
        end
        if (wind_duration>=min_duration_wait&&c(find(ymesh(:,1)==ms_pos(ms,2,tstep-medtime+2)),...
                find(xmesh(1,:)==ms_pos(ms,1,tstep-medtime+2)),tstep)>threshold/2&&...
                (meas_ms(ms,1,tstep-medtime+1)<threshold))||...
                (msbackwind(ms)==1&&(meas_ms(ms,1,tstep-medtime+1)>threshold/2))
            %%% end current timeplan
            %%% wait for another 3 timesteps before considering
            %%% moving again, unless wind direction changes
            waiting(ms)=3;
        end
        waiting(ms)=max([waiting(ms)-1 0]);
    end
    %%%% define external curve with properly ordered sensors
    ms_peripheral_pos=ms_pos(meas_ms(:,1,tstep-medtime+1)<0.01,:,tstep-medtime+2);
    [ordered_indices] = renumber_sensors_closed_curve(squeeze(ms_peripheral_pos));
    ordered_pos = ms_peripheral_pos(ordered_indices, :);
    %%%%
    %%%%
    tstep=tstep+1;
    hold off
    [c2, h2] = contourf(xmesh, ymesh, squeeze(c(:,:,tstep)), clist2);
    colormap(1-bone)
    movegui(fms7,'northeast');
    set(gcf,'Color',[1,1,1]);
    title(['Mobile sensor movement, t=',num2str(t(tstep)),'s'])
    hold on
    plot([ordered_pos(:,1); ordered_pos(1,1)],[ordered_pos(:,2); ordered_pos(1,2)],'b.-','MarkerSize',6)
    plot([ms_pos(:,1,tstep-medtime+1); ms_pos(1,1,tstep-medtime+1)],[ms_pos(:,2,tstep-medtime+1);...
        ms_pos(1,2,tstep-medtime+1)],'b.','MarkerSize',1)
    plot(ms_pos((mstomove>0),1,tstep-medtime+1),ms_pos((mstomove>0),2,tstep-medtime+1),'r.','MarkerSize',16)
    if exist('tailms','var')==1
        plot([xmin xmax],-1/tan(direction)*[xmin-ms_pos(tailms,1,tstep-medtime+1)...
            xmax-ms_pos(tailms,1,tstep-medtime+1)]+ms_pos(tailms,2,tstep-medtime+1),'r--','LineWidth',1)
    end
    plot(ms_pos((msbackwind>0),1,tstep-medtime+1),ms_pos((msbackwind>0),2,tstep-medtime+1),'k.','MarkerSize',16)
    xlim(xlimits)
    ylim(ylimits)
%     for ms=1:Nm
%         txt = num2str(ms);
%         text(ms_pos(ms,1,tstep-medtime+1)+25,ms_pos(ms,2,tstep-medtime+1),txt)
%     end
    %%%% compute metrics
    %%%% percentage of ms sensors in gas
    percin(tstep-medtime+1)=count_ms_in(meas_ms(:,1,tstep-medtime),threshold);
    %%%% fraction of ms_area/gas_area
    %area_fraction(tstep-medtime+1)=find_areas_fraction(ms_pos(:,:,tstep-medtime+1),...
    %    c(:,:,tstep),threshold,resolution_step);
    area_fraction(tstep-medtime+1)=find_areas_fraction(ordered_pos,...
        c(:,:,tstep),threshold,resolution_step);
    %%% summary of distances from threshold gas boundary
    %axis equal
    configure_graph(xmin, xmax, ymin, ymax, xstep)
    %configure_colorbar('$C$ ($mg/m^3$)');
    L1 = plot(nan, nan, 'k.','MarkerSize',16);
    L2 = plot(nan, nan, 'r.','MarkerSize',16);
    L22 = plot(nan, nan, 'b.','MarkerSize',16);
    L3 = plot(nan, nan, 'r--');
    legend([L1, L2, L22, L3], {'Backwind sensors',...
        'Front sensors', 'Neutral sensors','Classification Boundary'})
    pause(0.1)
    if tstep==medtime+1||tstep>=75&&tstep<=80
        o=[];
    end
end
clear fms7 c2 h2
%% Part VII: Plot Final Results and Metrics
figure()
colorsms = cool(Nm);
for ms=1:Nm
    plot(squeeze(ms_pos(ms,1,:)),squeeze(ms_pos(ms,2,:)),'Color',colorsms(ms,:),'MarkerSize',12)
    hold on
end
for ms=1:Nm
    plot(squeeze(ms_pos(ms,1,1)),squeeze(ms_pos(ms,2,1)),'o','Color',colorsms(ms,:),'MarkerSize',12)
    hold on
    if directionstart>medtime
    plot(squeeze(ms_pos(ms,1,directionstart-medtime)),squeeze(ms_pos(ms,2,directionstart-medtime)),'d','Color',colorsms(ms,:),'MarkerSize',12)
    hold on
    end
    plot(squeeze(ms_pos(ms,1,timesteps-medtime+1)),squeeze(ms_pos(ms,2,timesteps-medtime+1)),'+','Color',colorsms(ms,:),'MarkerSize',12)
    hold on
end
configure_graph(xmin, xmax, ymin, ymax, xstep)
xlim([-600 600])
ylim([-100 1000])
title({'Orbit of M.S.'})
L4 = plot(nan, nan, 'bo','MarkerSize',12);
L5 = plot(nan, nan, 'bd','MarkerSize',12);
L6 = plot(nan, nan, 'b+','MarkerSize',12);
legend([L4, L5, L6], {'Start position', 'Position at wind change','End position'})
%%%% metric 1---erroneous ms in gas
figure()
timeaxis=medtime:timesteps;
plot(timeaxis,percin,'-o','Color','b','LineWidth',2)
grid on
xlabel('Time (seconds)','Interpreter', 'latex','FontSize',14)
ylabel('\% of Mobile Sensors in gas','Interpreter', 'latex','FontSize',14)
ylim([0 100])
title('Percentage of M.S. sensors in gas area at the end of each timestep')
set(gca, 'TickLabelInterpreter', 'latex');

%%%% metric 2--- area percentages
figure()
timeaxis=medtime:timesteps;
plot(timeaxis,area_fraction,'-o','Color','b','LineWidth',2)
grid on
xlabel('Time (seconds)','Interpreter','latex','FontSize',14)
ylabel('$E_{MSp}/E_{Gas}$','Interpreter','latex','FontSize',14)
%ylim([0 1])
title('Areas fraction at the end of each timestep')
set(gca, 'TickLabelInterpreter', 'latex');
