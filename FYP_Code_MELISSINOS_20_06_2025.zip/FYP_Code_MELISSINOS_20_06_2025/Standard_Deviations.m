function [sigmax, sigmay, sigmaz]=Standard_Deviations(x)
% Set dispersion coefficients.
% ay = 0.14;  by = 0.92;  az = 0.53; bz = 0.73;  %% unstable
ay = 0.06;  by = 0.92;  az = 0.15; bz = 0.70;  %% neutral
% ay = 0.02;  by = 0.82;  az = 0.05; bz = 0.61;  %% stable
sigmax = ay*abs(x).^by .* (x > 0);
sigmay = ay*abs(x).^by .* (x > 0);
sigmaz = az*abs(x).^bz .* (x > 0);
end