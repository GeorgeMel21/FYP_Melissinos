%*************************************************************************
%* MEng Project
%  Programmer: George Alexandros Melissinos (based on the work of CHAO LI, J.M.Stockie)
%  Last modify date: 04/03/2025
%*************************************************************************
%  Function description: 
%      - Plot the 4 sources model based on Gaussian model
%*************************************************************************

% Plot
[c2, h2] = contourf( xmesh, ymesh, squeeze(c(:,:,tstep)), clist,'HandleVisibility', 'off');

% Adjustment 
%clabel(c2, h2)
colormap(1-winter)
colorbar
xlabel('x (m)'), ylabel('y (m)')
title(['Zn concentration (mg/m^3), t=',num2str(t(tstep)),'sec'])
grid on;

% Sources
hold on;
plot( x, y, 'ro', 'MarkerEdgeColor', 'k', 'MarkerFaceColor',...
    'r','HandleVisibility', 'off')
text( x, y, label, 'FontSize', 14, 'FontWeight','bold' );
set(gca,'XTick',xmin:resolution_step*100:xmax);
set(gca,'YTick',ymin:resolution_step*100:ymax);
