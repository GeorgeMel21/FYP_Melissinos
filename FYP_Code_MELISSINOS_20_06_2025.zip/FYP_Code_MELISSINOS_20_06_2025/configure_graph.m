function configure_graph(xmin, xmax, ymin, ymax, step)
xlim([xmin xmax])
ylim([ymin ymax])
xlabel('X(m)','Interpreter','latex','FontSize',14)
ylabel('Y(m)','Interpreter','latex','FontSize',14)
xticks_f=xmin:step:xmax;
yticks_f=ymin:step:ymax;
% Create labels (empty by default)
x_tlabels = repmat({''}, size(xticks_f));
y_tlabels = repmat({''}, size(yticks_f));
label_positionsx = xmin:250:xmax;
label_positionsy = ymin:250:ymax;
[~, x_idx] = ismember(label_positionsx, xticks_f);
[~, y_idx] = ismember(label_positionsy, yticks_f);
x_tlabels(x_idx(x_idx ~= 0)) = arrayfun(@num2str, label_positionsx(x_idx ~= 0), 'UniformOutput', false);
y_tlabels(y_idx(y_idx ~= 0)) = arrayfun(@num2str, label_positionsy(y_idx ~= 0), 'UniformOutput', false);

xticks(xticks_f)
yticks(yticks_f)
xticklabels(x_tlabels);
yticklabels(y_tlabels);
set(gca, 'TickLabelInterpreter', 'latex');
grid on


end