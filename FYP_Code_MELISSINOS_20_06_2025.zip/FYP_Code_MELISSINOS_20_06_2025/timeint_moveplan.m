function actual_plan=timeint_moveplan(xi,yi,direction,tinterval,step)
%%%
%%% computes each ms tinterval-step movement plan
%%% inputs: xi, yi: ms position at the tinterval start
%%% direction: desired movement direction, tinterval: duration of time
%%% plan, step: grid minimum distance
%%% outputs: actual_plan: the final movement plan for this ms during this
%%% time interval, based on Manhattan distance tracking

% xi=25;
% yi=25;
% direction=pi/8;
% tinterval=10;
% step=25;

%ideal Euclidean route
xplan_id=xi+step*(1:tinterval)*cos(direction);
yplan_id=yi+step*(1:tinterval)*sin(direction);
actual_plan=zeros(tinterval,2);
previous_pos=[xi yi];
for tt=1:tinterval
    new_pos(1,:)=move_single_direct(previous_pos(1),previous_pos(2),'right',step);
    new_pos(2,:)=move_single_direct(previous_pos(1),previous_pos(2),'left',step);
    new_pos(3,:)=move_single_direct(previous_pos(1),previous_pos(2),'up',step);
    new_pos(4,:)=move_single_direct(previous_pos(1),previous_pos(2),'down',step);
    [mindist,bestchoice]=min(sum((new_pos-repmat([xplan_id(tt) yplan_id(tt)],[4 1])).^2,2));
    actual_plan(tt,:)=new_pos(bestchoice,:);
    previous_pos=new_pos(bestchoice,:);
end

end

% figure
% plot([xi xplan_id], [yi yplan_id],'-*')
% hold on
% plot([xi; actual_plan(:,1)], [yi; actual_plan(:,2)],'-o')
% grid on
% axis equal