function area_fraction=find_areas_fraction(ms_positions,ct,threshold,resolution_step)
Sens_area=polyarea([ms_positions(:,1); ms_positions(1,1)], [ms_positions(:,2); ms_positions(1,2)]);
Gas_area=sum(sum(ct>threshold))*resolution_step^2;
area_fraction=Sens_area/Gas_area;
end


