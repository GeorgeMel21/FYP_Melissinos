function sorted_pairs=sort_neighboring_pairs(cross_points)
% Compute distances between consecutive pairs (including Nm?1)
Nm=size(cross_points,1);
distances = zeros(Nm, 1);
for i=1:Nm
    next_i=mod(i,Nm)+1; % Handles wrap-around (N?1)
    distances(i) = norm(cross_points(i,:)-cross_points(next_i,:)); % Euclidean distance
end
% Create a list of pairs and their distances
pairs = [(1:Nm)', mod((1:Nm), Nm)' + 1]; % [1?2, 2?3, ..., N?1]
pair_distances = [pairs, distances]; % Format: [i, j, distance]

% Sort pairs by distance (descending order)
[~, sorted_indices] = sort(pair_distances(:, 3),'descend');
sorted_pairs = pair_distances(sorted_indices, :);
end