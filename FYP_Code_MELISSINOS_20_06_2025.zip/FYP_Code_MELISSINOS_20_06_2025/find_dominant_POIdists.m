function [Dominant_POIs,maxPOI_dist]=find_dominant_POIdists(unique_cross_points)
% input: cross_points: a N_POIs x 3 matrix which includes the final 
% POIs that are lie on cross points. First column includes the grid point
% Second the X-coordinate and Third the Y-Coordinate

%%% find distances between all POIs
POIdists=sqrt((unique_cross_points(:,2)-unique_cross_points(:,2)').^2+...
    (unique_cross_points(:,3)-unique_cross_points(:,3)').^2);
%%% find the pair(s) indices with the highest one
[POI_pair_ind,~]= find(ismember(POIdists, max(POIdists(:))));
POI_pair_ind_r=reshape(POI_pair_ind,[length(POI_pair_ind)/2 2]);
%%% max distance (2xinitial mobile sensor cycle radius)
maxPOI_dist=max(POIdists(:));
%%% find the pair(s) coordinates with the highest one
Dominant_POIs=[unique_cross_points(POI_pair_ind_r(:,1),2:3); unique_cross_points(POI_pair_ind_r(:,2),2:3)];

end