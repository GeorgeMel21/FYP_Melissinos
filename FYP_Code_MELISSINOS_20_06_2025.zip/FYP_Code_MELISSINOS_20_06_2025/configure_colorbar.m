function configure_colorbar(description)
colorb = colorbar;
colorb.TickLabelInterpreter='latex';
colorb.Label.String = description;
colorb.FontSize=14;
colorb.Label.FontSize=14;
colorb.Label.Interpreter = 'latex';

end