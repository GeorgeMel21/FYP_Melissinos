function [dCdx, dCdy] = compute_gradient_wls_regularized(xm, ym, ms_pos, C_measurements, K,lambda,wv)
% Find K nearest neighbors
[neighbors, dists] = knnsearch(ms_pos, [xm ym], 'K', K+1);
%neighbors = neighbors(2:end);  % Exclude self node
xj = ms_pos(neighbors, 1);
dx=xj(1)-xj(2:end);
yj = ms_pos(neighbors, 2);
dy=yj(1)-yj(2:end);
Cj = C_measurements(neighbors);
dC=Cj(1)-Cj(2:end);

weights = 1./(dists(2:end).^2 + 1e-6);
W=diag(weights);

A = [dx, dy, ones(size(dx))];
b = dC;
%sols = lscov(A, b, weights); 
D=eye(size(A,2),size(A,2));%-eye(size(A,1),size(A,2));
D(end,end)=0;
D(1:size(A,2)-1,1:size(A,2)-1)=D(1:size(A,2)-1,1:size(A,2)-1)-wv'*wv;
sols=(A'*W*A+lambda*(D'*D))\(A'*W*b);
dCdx = sols(1);  
dCdy = sols(2); 
%disp(cond(A'*W*A+lambda*(D'*D)))
end