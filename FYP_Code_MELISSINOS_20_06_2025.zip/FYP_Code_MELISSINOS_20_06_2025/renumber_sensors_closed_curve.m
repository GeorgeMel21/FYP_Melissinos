function [ordered_indices] = renumber_sensors_closed_curve(ms_positions)
    % Input: Nx2 matrix of [x,y] positions
    % Output: Indices of sensors ordered clockwise around centroid
    
    centroid = mean(ms_positions, 1);
    x_rel = ms_positions(:,1) - centroid(1);
    y_rel = ms_positions(:,2) - centroid(2);
    
    % Compute angles (-pi to pi)
    angles = atan2(y_rel, x_rel);
    
    % Sort indices by angle
    [~, ordered_indices] = sort(angles);
    
    %if nargout == 0
%         ordered_pos = ms_positions(ordered_indices, :);
%         figure
%         plot([ordered_pos(:,1); ordered_pos(1,1)], ...
%              [ordered_pos(:,2); ordered_pos(1,2)], '-o');
%         axis equal;
    %end
end