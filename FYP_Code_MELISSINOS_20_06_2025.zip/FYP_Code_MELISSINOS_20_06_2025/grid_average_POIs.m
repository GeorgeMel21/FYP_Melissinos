function grid_average=grid_average_POIs(grid_index,grid_number,grid_record,midpoint_record)
%%%% finds the average POI from the midpoints within each grid block
grid_average = [grid_index' zeros(grid_number,2)];
%%% number of midpoint numbers ic
grid_mid_numbers=sum(grid_record(:,2:end)>0,2);
for i = 1:grid_number
    grid_average(i,2)=mean(midpoint_record(grid_record(i,2:grid_mid_numbers(i)+1),2));
    grid_average(i,3)=mean(midpoint_record(grid_record(i,2:grid_mid_numbers(i)+1),3));
end
grid_average(isnan(grid_average))=0;
end