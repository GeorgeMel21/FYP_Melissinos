function [dCdx, dCdy] = compute_gradient_wls(xm, ym, ms_pos, C_measurements, K)
% Find K nearest neighbors
[neighbors, dists] = knnsearch(ms_pos, [xm ym], 'K', K+1);
%neighbors = neighbors(2:end);  % Exclude self node
xj = ms_pos(neighbors, 1);
yj = ms_pos(neighbors, 2);
Cj = C_measurements(neighbors);

weights = 1./(dists.^2 + 1e-6);

A = [xj, yj, ones(size(xj))];
b = Cj;
sols = lscov(A, b, weights); 

dCdx = sols(1);  
dCdy = sols(2);  
end